problems = [
    # Problems from Harsh-Pandey-Hp-Day-8-Problem-Statement.docx
    {
        "filename": "NumberGuessingGame.java",
        "classname": "NumberGuessingGame",
        "main": """import java.util.Scanner;

public class NumberGuessingGame {

    public static int generateGuess(int low, int high) {
        return low + (int)(Math.random() * (high - low + 1));
    }

    public static String getUserFeedback(Scanner sc, int guess) {
        System.out.println("Computer guesses: " + guess);
        System.out.print("Is the guess (high/low/correct)? ");
        return sc.next().toLowerCase();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int low = 1, high = 100;
        boolean found = false;
        while (!found && low <= high) {
            int guess = generateGuess(low, high);
            String feedback = getUserFeedback(sc, guess);
            if (feedback.equals("correct")) {
                System.out.println("Computer guessed your number!");
                found = true;
            } else if (feedback.equals("high")) {
                high = guess - 1;
            } else if (feedback.equals("low")) {
                low = guess + 1;
            }
        }
    }
}
"""
    },
    {
        "filename": "MaximumOfThreeNumbers.java",
        "classname": "MaximumOfThreeNumbers",
        "main": """import java.util.Scanner;

public class MaximumOfThreeNumbers {

    public static int[] inputThreeNumbers(Scanner sc) {
        int[] nums = new int[3];
        for(int i=0; i<3; i++) {
            System.out.print("Enter number " + (i+1) + ": ");
            nums[i] = sc.nextInt();
        }
        return nums;
    }

    public static int findMaximum(int[] nums) {
        int max = nums[0];
        for(int i=1; i<nums.length; i++)
            if(nums[i] > max) max = nums[i];
        return max;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] nums = inputThreeNumbers(sc);
        int max = findMaximum(nums);
        System.out.println("Maximum value: " + max);
    }
}
"""
    },
    {
        "filename": "PrimeNumberChecker.java",
        "classname": "PrimeNumberChecker",
        "main": """import java.util.Scanner;

public class PrimeNumberChecker {

    public static boolean isPrime(int num) {
        if(num < 2) return false;
        for(int i = 2; i <= Math.sqrt(num); i++)
            if(num % i == 0) return false;
        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number to check prime: ");
        int num = sc.nextInt();
        System.out.println(num + (isPrime(num) ? " is prime" : " is not prime"));
    }
}
"""
    },
    {
        "filename": "FibonacciSequenceGenerator.java",
        "classname": "FibonacciSequenceGenerator",
        "main": """import java.util.Scanner;

public class FibonacciSequenceGenerator {

    public static void printFibonacci(int n) {
        int a = 0, b = 1;
        System.out.print(a);
        for(int i=1; i<n; i++) {
            System.out.print(" " + b);
            int temp = b;
            b = a + b;
            a = temp;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of terms: ");
        int n = sc.nextInt();
        printFibonacci(n);
    }
}
"""
    },
    {
        "filename": "PalindromeChecker.java",
        "classname": "PalindromeChecker",
        "main": """import java.util.Scanner;

public class PalindromeChecker {

    public static String inputString(Scanner sc) {
        System.out.print("Enter a string: ");
        return sc.nextLine();
    }

    public static boolean isPalindrome(String text) {
        int start = 0, end = text.length()-1;
        while(start < end)
            if(text.charAt(start++) != text.charAt(end--)) return false;
        return true;
    }

    public static void displayResult(String text, boolean result) {
        System.out.println("'" + text + "' is " + (result ? "a palindrome" : "not a palindrome"));
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String text = inputString(sc);
        boolean result = isPalindrome(text);
        displayResult(text, result);
    }
}
"""
    },
    {
        "filename": "FactorialUsingRecursion.java",
        "classname": "FactorialUsingRecursion",
        "main": """import java.util.Scanner;

public class FactorialUsingRecursion {

    public static int factorial(int n) {
        if(n <= 1) return 1;
        else return n * factorial(n-1);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number: ");
        int n = sc.nextInt();
        int result = factorial(n);
        System.out.println("Factorial of " + n + " is " + result);
    }
}
"""
    },
    {
        "filename": "GCDLCMCalculator.java",
        "classname": "GCDLCMCalculator",
        "main": """import java.util.Scanner;

public class GCDLCMCalculator {

    public static int gcd(int a, int b) {
        if (b == 0) return a;
        return gcd(b, a % b);
    }

    public static int lcm(int a, int b) {
        return (a * b) / gcd(a, b);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter first number: ");
        int a = sc.nextInt();
        System.out.print("Enter second number: ");
        int b = sc.nextInt();

        System.out.println("GCD: " + gcd(a, b));
        System.out.println("LCM: " + lcm(a, b));
    }
}
"""
    },
    {
        "filename": "TemperatureConverter.java",
        "classname": "TemperatureConverter",
        "main": """import java.util.Scanner;

public class TemperatureConverter {

    public static double fahrenheitToCelsius(double f) {
        return (f - 32) * 5 / 9;
    }

    public static double celsiusToFahrenheit(double c) {
        return c * 9 / 5 + 32;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Convert (1) Fahrenheit to Celsius or (2) Celsius to Fahrenheit? Enter 1 or 2: ");
        int choice = sc.nextInt();
        if(choice == 1) {
            System.out.print("Enter Fahrenheit: ");
            double f = sc.nextDouble();
            System.out.println("Celsius: " + fahrenheitToCelsius(f));
        } else {
            System.out.print("Enter Celsius: ");
            double c = sc.nextDouble();
            System.out.println("Fahrenheit: " + celsiusToFahrenheit(c));
        }
    }
}
"""
    },
    {
        "filename": "BasicCalculator.java",
        "classname": "BasicCalculator",
        "main": """import java.util.Scanner;

public class BasicCalculator {

    public static double add(double a, double b) { return a + b; }
    public static double subtract(double a, double b) { return a - b; }
    public static double multiply(double a, double b) { return a * b; }
    public static double divide(double a, double b) { return b != 0 ? a / b : Double.NaN; }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Choose operation (+, -, *, /): ");
        char op = sc.next().charAt(0);
        System.out.print("Enter first number: ");
        double a = sc.nextDouble();
        System.out.print("Enter second number: ");
        double b = sc.nextDouble();
        double result = 0.0;
        switch(op) {
            case '+': result = add(a, b); break;
            case '-': result = subtract(a, b); break;
            case '*': result = multiply(a, b); break;
            case '/': result = divide(a, b); break;
            default: System.out.println("Invalid operation"); return;
        }
        System.out.println("Result: " + result);
    }
}
"""
    },

    # Problems from Harsh-Pandey-Hp-Day-8-Problem-Statements-for-Practice.docx
    {
        "filename": "TimeZonesZonedDateTime.java",
        "classname": "TimeZonesZonedDateTime",
        "main": """import java.time.ZoneId;
import java.time.ZonedDateTime;

public class TimeZonesZonedDateTime {
    public static void displayTime(String zone) {
        ZonedDateTime zdt = ZonedDateTime.now(ZoneId.of(zone));
        System.out.println(zone + ": " + zdt.toLocalTime());
    }

    public static void main(String[] args) {
        displayTime("GMT");
        displayTime("Asia/Kolkata"); // IST
        displayTime("America/Los_Angeles"); // PST
    }
}
"""
    },
    {
        "filename": "DateArithmetic.java",
        "classname": "DateArithmetic",
        "main": """import java.time.LocalDate;
import java.util.Scanner;

public class DateArithmetic {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a date (yyyy-MM-dd): ");
        String dateInput = sc.nextLine();
        LocalDate date = LocalDate.parse(dateInput);

        LocalDate added = date.plusDays(7).plusMonths(1).plusYears(2).minusWeeks(3);
        System.out.println("Final date: " + added);
    }
}
"""
    },
    {
        "filename": "DateFormatting.java",
        "classname": "DateFormatting",
        "main": """import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateFormatting {
    public static void main(String[] args) {
        LocalDate date = LocalDate.now();
        System.out.println(date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        System.out.println(date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        System.out.println(date.format(DateTimeFormatter.ofPattern("EEE, MMM dd, yyyy")));
    }
}
"""
    },
    {
        "filename": "DateComparison.java",
        "classname": "DateComparison",
        "main": """import java.time.LocalDate;
import java.util.Scanner;

public class DateComparison {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter first date (yyyy-MM-dd): ");
        LocalDate d1 = LocalDate.parse(sc.nextLine());
        System.out.print("Enter second date (yyyy-MM-dd): ");
        LocalDate d2 = LocalDate.parse(sc.nextLine());

        if(d1.isBefore(d2))
            System.out.println("First date is before second date.");
        else if(d1.isAfter(d2))
            System.out.println("First date is after second date.");
        else
            System.out.println("Both dates are equal.");
    }
}
"""
    }
]

def create_java_files(problems):
    for p in problems:
        with open(p["filename"], "w") as f:
            f.write(p["main"])

create_java_files(problems)
print("Java files generated for all Day-8 problem statements and date/time practice.")

